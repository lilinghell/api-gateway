package com.hell.redis.entity;

import lombok.Data;

@Data
public class Msg {
    private String id;
    private String name;
}
